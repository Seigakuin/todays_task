# type: ignore
# flake8: noqa

"""Cards  -
テーマ：
-

手順：
-

課題：　
-

"""
