# Task12
# テーマ：　Dictionaryをforループ2


# * 以下にあるリストから「出力」のようにデータを表示しなさい。

"""
注意
- for ループのなかにfor ループを使うこと
"""

"""
#### スタートコード (これはコピペしても良い)    *  **???** の箇所を自分のコードに置き換えること
myclass = {
    'A': ['Tom', 'John'],
    'B': ['Cathy', 'Ben'],
    'C': ['Karen', 'George']
}

for item in myclass:
    print("------")
    print(???)
    for ??? in ???:
        print(???)



#### 出力
------
A:
Tom
John
------
B:
Cathy
Ben
------
C:
Karen
George


"""

# この下にコードを書く
