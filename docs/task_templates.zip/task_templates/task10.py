# Task10
# テーマ：　Listの出力(応用)
# 複数形にしよう

"""
以下のような出力になるようにコードを完成しなさい

注意
- `new_list`に新しい要素を足していく

#### スタートコード (これはコピペしても良い)    *  **???** の箇所を自分のコードに置き換えること
mylist = ["person", "teacher", "student"]

new_list = []
for item in mylist:
    if ???:
        ???
    else:
        ???
print(new_list)


#### 出力
['people', 'teachers', 'students']


"""


# この下にコードを書く
