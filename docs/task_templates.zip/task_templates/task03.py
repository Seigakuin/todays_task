# Task03
# テーマ：　for loopの練習, if / elif / else の練習
# "FizzBuzz"

"""
スタートコード (これはコピペしても良い)    *  **???** の箇所を自分のコードに置き換えること
for i in range(1, 30):
    if ???:
        print(???)
    elif ???:
        print(???)
    elif ???:
        print(???)
    else:
        print(i)


出力
```python
1
2
Fizz
4
Buzz
Fizz
7
8
Fizz
Buzz
11
Fizz
13
14
FizzBuzz
16
17
Fizz
19
Buzz
Fizz
22
23
Fizz
Buzz
# 続く
"""

# この下にコードを書く
