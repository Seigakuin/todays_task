# Task05
# テーマ：　while 練習
# 前回、for ループで作った“Fizz Buzz”を while 文を使って書き換えなさい

"""
スタートコード (これはコピペしても良い)    *  **???** の箇所を自分のコードに置き換えること

i = 1
while ???:
    if ???:
        print(???)
    elif ???:
        print(???)
    elif ???:
        print(???)
    else:
        print(i)
    ??? # ここが大事！


出力
1
2
Fizz
4
Buzz
Fizz
7
8
Fizz
Buzz
11
Fizz
13
14
FizzBuzz
16
17
Fizz
19
Buzz
# 続く
"""

# この下にコードを書く
