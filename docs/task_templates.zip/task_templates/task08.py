# Task08
# テーマ：　配列 (list) の出力2

"""
注意
- `apple`のときだけは出力が違う。 `if`を使って条件分岐を行う
- `mylist`に要素を足したり、順番を変えたりしても同じ出力になるようにする

#### スタートコード (これはコピペしても良い)    *  **???** の箇所を自分のコードに置き換えること
mylist = ["apple", "orange", "banana"]

for ??? in ???:
    if ???:
        print(??? + " is my favorite fruit")
    else:
        ???


#### 出力
apple is my favorite fruit
orange is OK
banana is OK
"""


# この下にコードを書く
