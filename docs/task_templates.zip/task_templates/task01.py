# Task01
# テーマ：　print() の練習
# "Hello world" を出力


# print()


# 出力
# Hello, world!

# この下にコードを書く
