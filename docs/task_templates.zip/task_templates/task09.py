# Task09
# テーマ：　配列 (list) の入力
# 注意
# - listに付け足す関数は？
# - listから要素を削除する関数は？

"""
#### スタートコード (これはコピペしても良い)    *  **???** の箇所を自分のコードに置き換えること
mylist = ["apple", "orange", "banana"]

mylist.???("melon")
mylist.???("grapes")
print(mylist)

mylist.???(2) # 3番目の"banana"を削除

print(mylist)


#### 出力
[“apple”, “orange”, “banana”, “melon”, “grapes”]
[“apple”, “orange”, “melon”, “grapes”]

"""


# この下にコードを書く
