# Task07
# テーマ：　配列 (list) の出力

# スタートコード (これはコピペしても良い)    *  **???** の箇所を自分のコードに置き換えること
mylist = ["apple", "orange", "banana"]
# print(???)


# 出力
# orange


# この下にコードを書く
